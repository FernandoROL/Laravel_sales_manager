## SAST - Semgrep

**Findings: 5**

| Regra | Regra (Completa) | Severidade | Código | Descrição |
| --- | --- | --- | --- | --- |
| github-actions-mutable-action-tag | yaml.github-actions.security.github-actions-mutable-action-tag.github-actions-mutable-action-tag | WARNING | `.github/workflows/scans.yml:21` | GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling su |
| github-actions-mutable-action-tag | yaml.github-actions.security.github-actions-mutable-action-tag.github-actions-mutable-action-tag | WARNING | `.github/workflows/scans.yml:97` | GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling su |
| github-actions-mutable-action-tag | yaml.github-actions.security.github-actions-mutable-action-tag.github-actions-mutable-action-tag | WARNING | `.github/workflows/scans.yml:106` | GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling su |
| detected-bcrypt-hash | generic.secrets.security.detected-bcrypt-hash.detected-bcrypt-hash | ERROR | `database/factories/UserFactory.php:24` | bcrypt hash detected |
| laravel-recibo-enviado-por-get | github.semgrep.laravel-recibo-enviado-por-get | WARNING | `routes/web.php:61` | O controlador de recibos envia e-mail. Exija um POST com proteção CSRF para acionar o envio. |

Os achados precisam de triagem para classificação como verdadeiro ou falso positivo.

## SCA - OSV-Scanner

**Findings: 49**

| Dependência | Versão | Vulnerabilidade | Versão corrigida (OSV) | Arquivo de origem |
| --- | --- | --- | --- | --- |
| guzzlehttp/guzzle | 7.9.2 | [GHSA-94pj-82f3-465w](https://osv.dev/vulnerability/GHSA-94pj-82f3-465w) | 7.14.2 | `composer.lock` |
| guzzlehttp/guzzle | 7.9.2 | [GHSA-cwxw-98qj-8qjx](https://osv.dev/vulnerability/GHSA-cwxw-98qj-8qjx) | 7.12.1 | `composer.lock` |
| guzzlehttp/guzzle | 7.9.2 | [GHSA-f283-ghqc-fg79](https://osv.dev/vulnerability/GHSA-f283-ghqc-fg79) | 7.15.1 | `composer.lock` |
| guzzlehttp/guzzle | 7.9.2 | [GHSA-f7vp-7xgx-4w4r](https://osv.dev/vulnerability/GHSA-f7vp-7xgx-4w4r) | 7.15.2, 8.0.1 | `composer.lock` |
| guzzlehttp/guzzle | 7.9.2 | [GHSA-g446-98w2-8p5w](https://osv.dev/vulnerability/GHSA-g446-98w2-8p5w) | 7.12.3 | `composer.lock` |
| guzzlehttp/guzzle | 7.9.2 | [GHSA-h95v-h523-3mw8](https://osv.dev/vulnerability/GHSA-h95v-h523-3mw8) | 7.15.1 | `composer.lock` |
| guzzlehttp/guzzle | 7.9.2 | [GHSA-v5mv-p594-2x33](https://osv.dev/vulnerability/GHSA-v5mv-p594-2x33) | 7.15.2, 8.0.1 | `composer.lock` |
| guzzlehttp/guzzle | 7.9.2 | [GHSA-wm3w-8rrp-j577](https://osv.dev/vulnerability/GHSA-wm3w-8rrp-j577) | 7.15.1 | `composer.lock` |
| guzzlehttp/guzzle | 7.9.2 | [GHSA-wpwq-4j6v-78m3](https://osv.dev/vulnerability/GHSA-wpwq-4j6v-78m3) | 7.12.1 | `composer.lock` |
| guzzlehttp/psr7 | 2.7.0 | [GHSA-34xg-wgjx-8xph](https://osv.dev/vulnerability/GHSA-34xg-wgjx-8xph) | 2.10.2 | `composer.lock` |
| guzzlehttp/psr7 | 2.7.0 | [GHSA-c2w2-prh8-qm98](https://osv.dev/vulnerability/GHSA-c2w2-prh8-qm98) | 2.12.3 | `composer.lock` |
| guzzlehttp/psr7 | 2.7.0 | [GHSA-hq7v-mx3g-29hw](https://osv.dev/vulnerability/GHSA-hq7v-mx3g-29hw) | 2.10.2 | `composer.lock` |
| guzzlehttp/psr7 | 2.7.0 | [GHSA-vm85-hxw5-5432](https://osv.dev/vulnerability/GHSA-vm85-hxw5-5432) | 2.12.1 | `composer.lock` |
| laravel/framework | v10.48.29 | [GHSA-5vg9-5847-vvmq](https://osv.dev/vulnerability/GHSA-5vg9-5847-vvmq) | 13.10.0, 12.60.0 | `composer.lock` |
| laravel/framework | v10.48.29 | [GHSA-63hm-g96r-2m2q](https://osv.dev/vulnerability/GHSA-63hm-g96r-2m2q) | 12.71.0, 13.40.0 | `composer.lock` |
| laravel/framework | v10.48.29 | [GHSA-crmm-hgp2-wgrp](https://osv.dev/vulnerability/GHSA-crmm-hgp2-wgrp) | 13.12.0, 12.61.1 | `composer.lock` |
| laravel/framework | v10.48.29 | [GHSA-f9x3-7vq9-cph6](https://osv.dev/vulnerability/GHSA-f9x3-7vq9-cph6) | 13.27.0, 12.68.0, 11.56.1 | `composer.lock` |
| laravel/framework | v10.48.29 | [GHSA-jh5r-qr3c-85q8](https://osv.dev/vulnerability/GHSA-jh5r-qr3c-85q8) | 12.69.0, 13.30.0 | `composer.lock` |
| league/commonmark | 2.6.1 | [GHSA-29pj-957v-52mc](https://osv.dev/vulnerability/GHSA-29pj-957v-52mc) | 2.9.0 | `composer.lock` |
| league/commonmark | 2.6.1 | [GHSA-2q4p-g7hv-5rgv](https://osv.dev/vulnerability/GHSA-2q4p-g7hv-5rgv) | 2.9.0 | `composer.lock` |
| league/commonmark | 2.6.1 | [GHSA-3527-qv2q-pfvx](https://osv.dev/vulnerability/GHSA-3527-qv2q-pfvx) | 2.7.0 | `composer.lock` |
| league/commonmark | 2.6.1 | [GHSA-3q6v-r5mr-hxv8](https://osv.dev/vulnerability/GHSA-3q6v-r5mr-hxv8) | 2.10.2 | `composer.lock` |
| league/commonmark | 2.6.1 | [GHSA-4v6x-c7xx-hw9f](https://osv.dev/vulnerability/GHSA-4v6x-c7xx-hw9f) | 2.8.1 | `composer.lock` |
| league/commonmark | 2.6.1 | [GHSA-8rr7-cvq3-gmfh](https://osv.dev/vulnerability/GHSA-8rr7-cvq3-gmfh) | 2.10.0 | `composer.lock` |
| league/commonmark | 2.6.1 | [GHSA-97jj-33gv-5xf9](https://osv.dev/vulnerability/GHSA-97jj-33gv-5xf9) | 2.10.2 | `composer.lock` |
| league/commonmark | 2.6.1 | [GHSA-g2gp-3wwq-f4ph](https://osv.dev/vulnerability/GHSA-g2gp-3wwq-f4ph) | 2.9.0 | `composer.lock` |
| league/commonmark | 2.6.1 | [GHSA-hh8v-hgvp-g3f5](https://osv.dev/vulnerability/GHSA-hh8v-hgvp-g3f5) | 2.8.2 | `composer.lock` |
| league/commonmark | 2.6.1 | [GHSA-j8pm-gj4c-rq4x](https://osv.dev/vulnerability/GHSA-j8pm-gj4c-rq4x) | 2.9.1 | `composer.lock` |
| league/commonmark | 2.6.1 | [GHSA-jfm3-95jq-q3rf](https://osv.dev/vulnerability/GHSA-jfm3-95jq-q3rf) | 2.9.0 | `composer.lock` |
| league/commonmark | 2.6.1 | [GHSA-jjv6-8j6v-6j52](https://osv.dev/vulnerability/GHSA-jjv6-8j6v-6j52) | 2.9.1 | `composer.lock` |

Exibidos 30 de 49 findings. Os demais estão no log do SCA.

A versão corrigida é informada pelo OSV quando disponível. Verifique a compatibilidade antes de atualizar a dependência.
