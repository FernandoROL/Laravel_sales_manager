# Entrega acadêmica · Laravel Sales Manager em Docker

Comece por Reportagem-Seguranca-Docker.pdf para acompanhar as decisões. Use Apresentacao-Seguranca-Docker.pdf na exposição oral.

A pasta projeto/ reproduz o commit corrigido. Com Docker Compose v2.24 ou posterior, entre nela e execute:

    docker compose up --build -d
    docker compose exec sistema_gestao php artisan db:seed

Abra http://localhost:8989/dashboard e depois http://localhost:8989/salles. Clique em Email Receipt e confira o assunto Email Sale Recipt com:

    docker compose exec sistema_gestao tail -n 60 storage/logs/laravel.log

Em evidencias/, comece pelos três overview.md. A pasta original/ tem o resumo do YAML exato do professor. As pastas antes/ e depois/ preservam os arquivos brutos semgrep.json e osv.json. Consulte inventario-sca.csv para todos os avisos, incluindo as pendências, e correcoes.diff para a comparação de código. Os IDs e hashes de cada artefato constam nos arquivos execucao.json.

O resumo de SCA do professor mostra os primeiros 30 avisos. O CSV e os JSONs da comparação são completos. Os comandos de demonstração criam dados fictícios e o transporte local grava o recibo no log.
